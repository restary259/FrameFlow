# Changelog

## 0.1.0
- Initial "Hello world" mod structure and build scripts.
- Fabric Loom setup for Minecraft 1.21.x.