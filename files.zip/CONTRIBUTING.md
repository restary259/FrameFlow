# Contributing to FrameFlow

- Please submit issues and PRs for bugs, features, and testing reports.
- See [KNOWN_ISSUES.md](docs/KNOWN_ISSUES.md) and [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for guidelines on submitting crash and compatibility reports.
- Include full mod list, Java version, GPU, logs.