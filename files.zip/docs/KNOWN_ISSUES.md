# Known Issues

- System.gc() can cause pauses; it is triggered only with user consent.
- Sodium/OptiFine compatibility under active development.
- Aggressive cleanup may crash some GPUs/drivers.